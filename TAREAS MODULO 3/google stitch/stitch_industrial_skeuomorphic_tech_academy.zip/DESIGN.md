---
name: Heavy Industrial Scraptron
colors:
  surface: '#1a110b'
  surface-dim: '#1a110b'
  surface-bright: '#43372f'
  surface-container-lowest: '#150c07'
  surface-container-low: '#231a13'
  surface-container: '#281e17'
  surface-container-high: '#332821'
  surface-container-highest: '#3e322b'
  on-surface: '#f2dfd4'
  on-surface-variant: '#e2bfb0'
  inverse-surface: '#f2dfd4'
  inverse-on-surface: '#392e27'
  outline: '#a98a7d'
  outline-variant: '#5a4136'
  surface-tint: '#ffb693'
  primary: '#ffb693'
  on-primary: '#561f00'
  primary-container: '#ff6b00'
  on-primary-container: '#572000'
  inverse-primary: '#a04100'
  secondary: '#c8c6c6'
  on-secondary: '#303030'
  secondary-container: '#474747'
  on-secondary-container: '#b6b5b4'
  tertiary: '#2ae500'
  on-tertiary: '#053900'
  tertiary-container: '#1fb100'
  on-tertiary-container: '#053a00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcc'
  primary-fixed-dim: '#ffb693'
  on-primary-fixed: '#351000'
  on-primary-fixed-variant: '#7a3000'
  secondary-fixed: '#e4e2e1'
  secondary-fixed-dim: '#c8c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#79ff5b'
  tertiary-fixed-dim: '#2ae500'
  on-tertiary-fixed: '#022100'
  on-tertiary-fixed-variant: '#095300'
  background: '#1a110b'
  on-background: '#f2dfd4'
  surface-variant: '#3e322b'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: 0.08em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: 0.06em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: 0.06em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: 0.05em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0.05em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.04em
  body-lg:
    fontFamily: Space Mono
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.02em
  body-md:
    fontFamily: Space Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.1em
  label-md:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.12em
  label-sm:
    fontFamily: Space Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.15em
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
This design system captures an aesthetic of heavy orbital scrap engineering, retro-futuristic cyberpunk salvaging, and worn space industrialism. The UI simulates physical control consoles found in deep-space freight hulls, salvage cranes, and irradiated refinery machines. 

### Aesthetic Philosophy
- **Physicality & Tactility:** Every interface element behaves like mechanical steel, milled bakelite, or sheet metal stamped into place. Surfaces feel heavy, unyielding, and operational.
- **Atmospheric Wear:** The environment reflects oil spills, oxidized metal seams, and decades of cosmic dust. Clean corporate simplicity is rejected in favor of functional machinery, physical hazard demarcations, and utilitarian hardware.
- **Retro Hardware Fidelity:** Visuals balance analog mechanics (thick bevels, recessed rocker switches, metal rivets) with cathode-ray terminal (CRT) displays and monochrome LCD instrumentation readouts.

## Colors
The palette is built from industrial hazards, corroded steel, and illuminated phosphorus phosphor terminals.

### Core Roles
- **Primary (`#FF6B00` Hazard Orange):** Applied to warning beacons, primary action levers, active overrides, and high-voltage warnings. Supported by mechanical shades `#D95C14` and `#B34400` for pressed bevel reliefs.
- **Secondary (`#333333` Chipped Lead Steel):** Structural plating, heavy physical panels, chassis frames, and stamped metal casing (`#222222`, `#1F1D1B`).
- **Tertiary (`#39FF14` CRT Phosphor Green):** Monitored telemetry, diagnostic matrices, active terminal lines, and live readouts with scanline illumination. Supported by Amber LCD (`#FFB000`) for non-critical operational warnings.
- **Neutral (`#1A110B` Corroded Rust Base):** Deep oxidised foundation plates, weathered background canvas (`#120A06`), and recessed machinery troughs (`#2C1E16`).

## Typography
Typographic rules strictly reinforce heavy machinery operation and field maintenance manuals.

- **Headlines:** Set exclusively in uppercase using bold, technical geometry. Titles replicate stamped cast-iron signage and stencil serial markers on bulkheads.
- **Data & Readouts:** Rendered in fixed-width monospace to align technical specifications, system diagnostics, and coordinate maps directly along columnar grids.
- **Terminal Glow:** Informational readouts using phosphor green or amber tokens apply a strict text shadow (`0 0 8px rgba(57, 255, 20, 0.45)`) to replicate electron beam bleeding through curved cathode glass.

## Layout & Spacing
The layout follows a modular structural chassis inspired by standard 19-inch server racks and heavy equipment dashboards.

- **Grid Architecture:** 12-column rigid desktop layout that snaps into 4-column chassis bays on mobile. Every modular section is divided by structural steel mullions rather than soft whitespace.
- **Seams & Clearances:** Components pack tightly, mimicking functional control arrays where dead space is avoided to maximize operative screen area.
- **Responsive Handling:** Layouts do not fluidly glide; they mechanically step down at standard device thresholds (`640px`, `1024px`, `1440px`), stacking chassis racks vertically while maintaining rigid padding boundaries.

## Elevation & Depth
Elevation is achieved purely through tactile mechanical skeuomorphism: stamped bevels, machined metal seams, and recessed cavities.

### Surface Hierarchy
- **Level -1 (Recessed Well):** Inset surfaces for CRT displays, toggle housings, and input pockets. Uses dual inset shadows: `inset 3px 3px 6px #000000, inset -2px -2px 4px rgba(255, 255, 255, 0.05)`.
- **Level 0 (Plate Chassis):** Flat rusted hull plating (`#1A110B`), delimited by welded joints or dark 1px separation grooves (`#0C0704`).
- **Level 1 (Bolted Panels):** Raised structural segments (`#222222` to `#333333`) framed by simulated light sources at 315 degrees: `1px solid #4D4D4D` (top/left highlight) and `2px solid #000000` (bottom/right drop shadow).
- **Level 2 (Physical Buttons & Push-Switches):** High-relief elements featuring multi-stop directional gradients, strong top-edge specularity, and dark cast shadows (`0 4px 0 #0D0805, 0 6px 12px rgba(0,0,0,0.8)`).
- **Hardware Detailing:** Corner anchors feature visible screw heads created with radial metallic gradients and a cross-cut 1px dark line.

## Shapes
Sharp, non-rounded angles (`0px`) are enforced across all elements to convey brutalist, unyielding machinery.

- **Chamfers & Angles:** Where visual differentiation is required, corners must use 45-degree mechanical chamfers (`clip-path: polygon(...)`) rather than radius curves.
- **Slits & Grilles:** Decorative ventilation vents, cooling grates, and intake slits appear in groupings of 3 to 7 horizontal bars across panel headers.

## Components

### Buttons & Actuators
- **Primary Push-Button:** Coated in hazard orange (`#FF6B00`), featuring a heavy raised 3D mechanical bevel. The resting state has an outer drop shadow of `0 5px 0 #802E00, 0 8px 10px #000`. When active (pressed), the element shifts down by `4px`, and the shadow reduces to an inset depression with an inner rim shadow.
- **Emergency / Lockout Switches:** Encased inside a striped yellow-and-black hazard frame with an acrylic toggle-lock cover aesthetic.
- **Ghost/Tertiary Actions:** Steel plates stamped into the background with engraved borders and phosphor green label typography.

### Inputs & Controls
- **Data Input Fields:** Deep-inset black troughs (`#0E0805`) framed with a 2px stepped inner border. Text displays in glowing phosphor green (`#39FF14`) with a steady non-blinking terminal block cursor.
- **Checkboxes & Toggle Switches:** Checkboxes are designed as recessed circular or square metal micro-switches that display an illuminated orange or green LED dot when active.
- **Segmented Radio Buttons:** Replaced by mechanical rocker switches or multi-position rotary knob visuals with engraved position notches.

### Containers & Chassis Cards
- **Machinery Panels:** Cards feature simulated metallic plates fastened at the four corners with simulated hex bolts or slotted screws. 
- **CRT Diagnostic Screens:** Dark glass display monitors featuring subtle horizontal scanlines (`repeating-linear-gradient` overlay), phosphor glow, and etched coordinate crosshairs in the corners.
- **Ventilation Strips:** Component footers feature industrial cooling louvers that expose the dark chassis underneath.

### Status Badges & Chips
- **Hazard Chips:** High-contrast warnings with diagonal safety hazard stripes (`#FF6B00` and `#000000`) at 45-degree angles, capped with industrial warning text.
- **System Telemetry Badges:** Bordered by 1px metallic borders with corner bracket notches, containing fixed-width status indicators (`ONLINE`, `PURGING`, `CRITICAL`).