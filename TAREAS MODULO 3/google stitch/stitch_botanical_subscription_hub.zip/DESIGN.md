---
name: Botanical Canopy
colors:
  surface: '#04170c'
  surface-dim: '#04170c'
  surface-bright: '#293e30'
  surface-container-lowest: '#011207'
  surface-container-low: '#0b1f14'
  surface-container: '#102417'
  surface-container-high: '#1a2e21'
  surface-container-highest: '#25392c'
  on-surface: '#d0e9d5'
  on-surface-variant: '#bbcbbc'
  inverse-surface: '#d0e9d5'
  inverse-on-surface: '#213528'
  outline: '#869587'
  outline-variant: '#3c4a3f'
  surface-tint: '#43e188'
  primary: '#60f99e'
  on-primary: '#00391c'
  primary-container: '#3ddc84'
  on-primary-container: '#005c31'
  inverse-primary: '#006d3b'
  secondary: '#a7d0b3'
  on-secondary: '#113722'
  secondary-container: '#2c513a'
  on-secondary-container: '#99c2a5'
  tertiary: '#60f99b'
  on-tertiary: '#00391b'
  tertiary-container: '#3cdc81'
  on-tertiary-container: '#005c2f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#66fea2'
  primary-fixed-dim: '#43e188'
  on-primary-fixed: '#00210e'
  on-primary-fixed-variant: '#00522b'
  secondary-fixed: '#c2edce'
  secondary-fixed-dim: '#a7d0b3'
  on-secondary-fixed: '#002110'
  on-secondary-fixed-variant: '#294e38'
  tertiary-fixed: '#65fe9f'
  tertiary-fixed-dim: '#43e185'
  on-tertiary-fixed: '#00210d'
  on-tertiary-fixed-variant: '#00522a'
  background: '#04170c'
  on-background: '#d0e9d5'
  surface-variant: '#25392c'
typography:
  display:
    fontFamily: Quicksand
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Quicksand
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Quicksand
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Quicksand
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Quicksand
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Quicksand
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title:
    fontFamily: Quicksand
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Nunito Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Nunito Sans
    fontSize: 10px
    fontWeight: '800'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
This design system establishes an immersive, living digital ecosystem driven by deep vegetal pigments rather than sterile dark modes or artificial blackened voids. It rejects synthetic blacks and cold grays in favor of verdant layers: dense forest canopies, fertile forest floors, rich moss, and vibrant chlorophyll vitality. 

The aesthetic is purely solid, organic, and tactile:
- **Zero Transparency / No Glassmorphism:** Every surface is rendered with 100% solid opacity. Depth is constructed through strict tonal stepping of rich forest greens rather than blurry translucency.
- **Organic Softness:** Micro and macro architecture borrow their curvature from succulent leaves, river pebbles, and natural stem contours, utilizing high-radius geometries (`rounded-3xl` to full pills).
- **Lush Immersion:** The emotional posture is calm, oxygenated, and protective yet precise. It transforms botanical vitality into a dependable, modern UI for plant science, ecological intelligence, and conservation tools.

## Colors
The palette abandons neutral blacks entirely. Every surface tier, border, and backdrop is infused with chlorophyll and fertile humus tones.

### Surface Tiers (Strictly 100% Solid Opacity)
- **Canvas Base (`#0b1c12` to `#0e2216`):** The ground floor representing dense, lightless rainforest floor. Used for primary page and viewport backgrounds.
- **Surface Low (`#12261a`):** Recessed containers, inset inputs, and secondary panels.
- **Surface Mid (`#163020`):** Default card layers, sidebars, and navigational trays.
- **Surface High (`#1b3a27`):** Elevated cards, active states, and elevated list items.
- **Surface Prominent (`#224731`):** Modal dialogues, floating sheets, and selected interactive segments.

### Botanical Accent & Interactive Hierarchy
- **Primary Interactive (`#3ddc84`):** Vibrant bio-luminescent chlorophyll green. Used for key call-to-actions, active progress bars, and critical indicators. High-contrast text on this color uses `#0b1c12`.
- **Secondary Accent (`#48e589`):** Bright sprouting emerald. Reserved for focus rings, hover pips, success validations, and dynamic charts.
- **Tertiary Accent (`#2ecc71`):** Vivid leaf green. Used for secondary toggles, badges, and active state highlights.

### Typography & Iconography Pigments
- **Text Primary (`#e6f7ec`):** Crisp pale-mint white ensuring effortless legibility against dark green strata (AAA compliant).
- **Text Secondary (`#9ec8aa`):** Fern sage tint for metadata, descriptions, and passive labels.
- **Text Muted (`#5c8a6b`):** Subdued moss green for borders, disabled states, and placeholder elements.

## Typography
The typographic architecture pairs the friendly, organic geometry of Quicksand for display titles and headings with the refined readability and balance of Nunito Sans for running body copy, data values, and metadata.

- **Headlines & Titles (Quicksand):** Feature soft circular terminals that mimic organic vascular forms. Used in weights 600 (SemiBold) and 700 (Bold) to deliver a confident botanical presence.
- **Body & Controls (Nunito Sans):** Delivers open counters, wide apertures, and superior optical legibility across dark vegetal surfaces.
- **Caps & Micro Labels:** Always tracked slightly wider (`0.02em` to `0.06em`) with extra bold weight to guarantee legible metrics against solid deep-green containers.

## Layout & Spacing
The layout adheres to a flexible 12-column grid on desktop, an 8-column layout on tablet, and a 4-column structure on mobile devices.

- **Fluid Rhythms:** Negative space mimics the breathing intervals found in natural flora canopy structures. Vertical spacing leans towards generous padding to give each solid module distinct presence.
- **Spatial Tokens:**
  - `space-xs` (4px): Micro-gaps between icons and adjacent text.
  - `space-sm` (8px): Compact element spacing, chip internal vertical padding, and input edge buffers.
  - `space-md` (16px): Standard gap for form rows, button padding, and sub-card divisions.
  - `space-lg` (24px): Standard card interior padding and panel spacing.
  - `space-xl` (40px): Section margins and macro dashboard boundaries.
- **Breakpoints:**
  - Mobile (`< 768px`): Margins reduce to `1rem` (`margin-sm`), single-column flows for complex card structures.
  - Tablet (`768px - 1024px`): Margins expand to `1.5rem`, multi-card rows collapse to 2 columns.
  - Desktop (`> 1024px`): Max container width standardizes at 1440px with `3rem` gutters (`margin-lg`).

## Elevation & Depth
In alignment with strict non-translucent requirements, depth is established using **solid tonal progression** and **deep vegetal-tinted ambient occlusion**.

1. **Pure Solid Tonal Stepping:**
   - Base canvas begins at `#0e2216`.
   - Resting elements rest on `#163020`.
   - Elevated items step to `#1b3a27`.
   - Floating panels and drawers utilize `#224731`.
2. **Organic Vegetal Shadows:**
   - Never use neutral black or gray shadows.
   - Ambient drop shadows use deeply saturated forest shadow tones (`#040a06` at 40% to 60% opacity) blended naturally onto the surrounding dark green canvases.
   - Example resting elevation: `0 4px 16px 0 #050d08`.
   - Example lifted elevation: `0 12px 32px -4px #040a06`.
3. **Solid Contour Borders:**
   - To separate identical green strata without shadows, rely on a crisp 1px solid stroke using `#224731` or `#2a593e`. No alpha channels or blurry semi-transparent borders.

## Shapes
The shape language takes inspiration from seeds, river stones, and botanical leaflets.

- **Primary Controls & Chips:** Fully pill-shaped (`rounded-full` or `9999px`) to maintain physical, tactile appeal reminiscent of organic seeds and buds.
- **Cards & Surfaces:** Large, generous radius tokens (`24px` to `32px` on desktop; `20px` on mobile) softening hard UI lines into organic containers.
- **Inner Corner Conformity:** Child elements nested inside cards scale down radius values proportionally (e.g., card at `24px` contains inputs at `14px` or `9999px` pills) to ensure harmonic nesting without corner clipping.

## Components

### Buttons
- **Primary:** Pill-shaped (`rounded-full`), solid `#3ddc84` background with `#0b1c12` text (Quicksand 700). Hover shifts background to `#48e589` with a subtle elevation raise. Focus ring is an offset 2px solid `#48e589`.
- **Secondary:** Solid `#224731` background with `#e6f7ec` text. Border is 1px solid `#2f6143`. Hover brightens background to `#2a593e`.
- **Ghost:** Solid `#0e2216` background (matching canvas) with `#3ddc84` text and 1.5px solid `#224731` contour.

### Chips & Badges
- Pill-shaped with strict minimum height of 32px for tactile tapping.
- Inactive state: Solid `#163020` fill, `#9ec8aa` text, 1px solid `#224731`.
- Active / Filtered state: Solid `#2ecc71` fill, `#0b1c12` bold text, zero border.

### Cards & Modules
- Solid `#163020` background, 24px corner radius (`rounded-3xl`), 24px internal padding (`space-lg`), bounded by a distinct 1px solid `#1b3a27` border.
- Hoverable cards transition background solidly to `#1b3a27` with an ambient `#040a06` drop shadow.

### Input Fields
- Solid `#12261a` background with 16px corner radius (`rounded-2xl`).
- Default border: 1.5px solid `#1b3a27`.
- Focus border: 2px solid `#3ddc84`. No glow or drop-shadow halo; clarity is achieved through sharp contrast.
- Input text: `#e6f7ec`; Placeholder text: `#5c8a6b`.

### Checkboxes & Radios
- Checkboxes: 20px boxes with rounded corners (`rounded-lg` / 6px). Checked state is a solid `#3ddc84` fill with a `#0b1c12` checkmark icon.
- Radios: Circular pill with solid `#12261a` background and a solid `#3ddc84` interior node when selected.

### Lists & Navigation
- List tiles sit inside a unified solid `#163020` container with items divided by 1px solid `#12261a` dividers.
- Active navigation items feature full pill pills rendered in solid `#224731` with `#3ddc84` leading icons and white-mint labels.