---
name: Voltage Terminal
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#cdc7aa'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#979177'
  outline-variant: '#4b4731'
  surface-tint: '#dec800'
  primary: '#ffffff'
  on-primary: '#373100'
  primary-container: '#fde400'
  on-primary-container: '#716500'
  inverse-primary: '#6a5f00'
  secondary: '#c6c6c6'
  on-secondary: '#303030'
  secondary-container: '#474747'
  on-secondary-container: '#b5b5b5'
  tertiary: '#ffffff'
  on-tertiary: '#003737'
  tertiary-container: '#00fbfc'
  on-tertiary-container: '#007071'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#fde400'
  primary-fixed-dim: '#dec800'
  on-primary-fixed: '#201c00'
  on-primary-fixed-variant: '#504700'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c6'
  on-secondary-fixed: '#1b1b1b'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#00fbfc'
  tertiary-fixed-dim: '#00dcdd'
  on-tertiary-fixed: '#002020'
  on-tertiary-fixed-variant: '#004f50'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.12em
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-voltage industrial utility, inspired by mission-critical heavy machinery consoles, warning iconography, and rapid-response instrumentation. It rejects subtle nuance in favor of absolute clarity, extreme visual hierarchy, and instant cognitive capture.

### Aesthetic Persona
- **Movement:** High-Contrast Industrial Brutalism & Technical Terminal.
- **Tone:** Uncompromising, electric, authoritative, urgent, hyper-functional.
- **Audience:** Operators, engineers, technical leads, and command teams operating in high-stakes, data-dense environments where ambiguity introduces error.
- **Visual Tension:** The system lives exclusively across binary states: absolute light emission (electric cadmium yellow) versus complete light absorption (pure carbon black). Zero intermediate grays or tonal gradients soften the boundary.

## Colors

The palette operates under a strict two-tone mandate. No mid-tone grays, slates, silvers, or desaturated tones are permitted across any layer or state. 

### Color Application Rules
- **Pure Black (`#000000`):** Acts as the foundational void or as ink over electric surfaces. Used for primary canvas backdrops, high-contrast typography resting on yellow planes, and negative-space containers.
- **Electric Yellow (`#FFE600`):** Acts as the primary kinetic agent. Used for heavy full-bleed structural cards, high-visibility data panels, critical action triggers, focus boundaries, and glowing data outputs.
- **Inverted States:** Contrast is preserved strictly through color reversal:
  - If a container is pure black (`#000000`), its borders, text, and active indicators are electric yellow (`#FFE600`).
  - If a panel is electric yellow (`#FFE600`), its borders, typography, and iconography are pure black (`#000000`).
- **Semantic Overrides:** To maintain zero-gray purity, warning, alert, and success states are expressed using pattern density, inverse fills, or flashing text states rather than third-party color injections.

## Typography

The typographic hierarchy balances expressive, industrial geometry (`Space Grotesk`) with uncompromising technical precision (`JetBrains Mono`).

### Application Guidelines
- **Case Rules:** All labels, navigation prompts, tags, and table headers must be rendered in `UPPERCASE` with aggressive letter-spacing (`0.08em` to `0.12em`).
- **Data Rendering:** Monospaced numerals and characters are strictly required for operational telemetry, tabular sets, timestamps, and input values.
- **Contrast Pairings:** 
  - Headlines on black canvases render exclusively in solid `#FFE600`.
  - Headlines and labels placed inside saturated `#FFE600` cards render exclusively in solid `#000000`.
- **Underlining & Emphasis:** Never use muted alpha colors for secondary information. Instead, employ strict font weight changes (`400` vs `700`) or inverse background highlight blocks.

## Layout & Spacing

The layout is built upon an architectural, high-density grid system that mirrors structural scaffolding.

### Layout Mechanics
- **Grid Structure:** 12-column layout on desktop, 8-column on tablet, and 4-column on mobile.
- **Section Enclosures:** Containers sit flush against grid boundaries. Rather than soft gutters creating arbitrary separation, sections are partitioned by deliberate 2px structural divider lines in pure `#FFE600` or `#000000`.
- **Information Density:** High density is favored over empty canvas. Spacing intervals follow strict multiples of 4px/8px, prioritizing rapid data legibility and scannability.
- **Responsive Stacking:** Multi-column dashboard blocks collapse into single-column vertical stacks on mobile viewports, retaining full border definition and inverse color logic.

## Elevation & Depth

This design system explicitly forbids shadows, atmospheric blurs, and pseudo-skeuomorphic depth.

### Structural Contrast Hierarchy
- **Zero Soft Shadows:** No `box-shadow` or `drop-shadow` blurs exist. Depth is established purely through hard chromatic planes and hard mechanical offsets.
- **Hard Offsets:** Raised interactive elements (such as pressed buttons or lifted dialogs) use a hard 4px or 8px offset with zero blur: `box-shadow: 4px 4px 0px 0px #FFE600` on black surfaces, or `box-shadow: 4px 4px 0px 0px #000000` on yellow surfaces.
- **Boundary Delineation:** 
  - Level 0 (Base Canvas): Solid `#000000`.
  - Level 1 (Dominant Containers): Solid `#FFE600` fill with `#000000` internal contents.
  - Level 2 (Sub-Panels inside Yellow): Solid `#000000` cutout box with `#FFE600` text and borders.
  - Overlays / Modals: Inverted solid surfaces surrounded by a continuous 3px solid border, paired with an opaque blocking scrim (either 100% black with a yellow wireframe frame or hatched 100% opacity micro-patterns).

## Shapes

The shape vocabulary is strictly non-filleted, raw, and geometric.

### Geometry Specifications
- **Corners:** Radius is set to `0px` universally across all interactive and layout components.
- **Borders & Strokes:** Hard edges with uniform line weights (1px for micro-separators, 2px for standard borders, 3px or 4px for emphasized active focus bounds).
- **Chamfers & Angles:** Occasional 45-degree corner cutouts (chamfers) may be applied to badges, tab items, or modal corners via CSS clipping path to reinforce the industrial machinery identity.

## Components

### Buttons
- **Primary:** Solid `#FFE600` background, solid `#000000` bold uppercase text, 0px border radius. Hover state: Inverse fill (`#000000` background, `#FFE600` text, 2px `#FFE600` solid border). Active state: 2px inward inset or hard 2px offset.
- **Secondary / Ghost:** Solid `#000000` background, 2px solid `#FFE600` border, `#FFE600` text. Hover state: Full `#FFE600` flood fill with `#000000` text.
- **Destructive / Caution:** Diagonal black-and-yellow hazard stripes (CSS repeating linear gradient) across a 4px accent bar with full `#FFE600` background and `#000000` typography.

### Input Fields
- **Base Canvas:** Solid `#000000` background, 2px `#FFE600` border, `#FFE600` monospaced text.
- **Focus State:** 4px `#FFE600` outline, solid yellow block caret cursor (`#FFE600`).
- **Placeholder:** Displayed with an explicit `// ` terminal-style prefix in uppercase mono.
- **Inverse Canvas Variant (inside yellow panels):** Solid `#FFE600` background, 2px `#000000` border, `#000000` text and `#000000` solid block cursor.

### Chips & Badges
- **Status Badges:** Solid `#FFE600` block pill with `#000000` text, or hollow `#000000` container with 1px `#FFE600` border and leading square bullet indicator (`■`).
- **Action Chips:** Monospaced label enclosed in hard brackets `[ LABEL ]`. On selection, fills with `#FFE600` solid color and inverts text to `#000000`.

### Checkboxes & Radio Buttons
- **Checkbox:** Square box with 2px `#FFE600` border on `#000000`. Checked state: Solid `#FFE600` fill with a pure black bold cross (`✕`) or square check.
- **Radio Button:** Diamond or square enclosure (retaining 0px roundedness). Selected state displays a centered solid square glyph inside the frame.

### Cards & Panels
- **Type A (High-Voltage Dominant):** Solid `#FFE600` fill. All inner labels, text, diagrams, and iconography render in deep `#000000`. Used to highlight priority instrumentation, primary modules, or status alerts.
- **Type B (Void Frame):** Solid `#000000` fill with continuous 2px `#FFE600` perimeter border. Internal elements use `#FFE600`.
- **Corner Markers:** Optional crosshair (`+`) or bracket glyphs pinned to the four internal corners of data cards for diagnostic aesthetic.

### Lists & Data Tables
- **Table Headers:** Solid `#FFE600` background ribbon with `#000000` uppercase monospaced labels.
- **Rows:** Alternating rows switch strictly between `#000000` background with `#FFE600` borders and inverted `#FFE600` hover highlights. No mid-tone alternating zebra stripes are permitted.