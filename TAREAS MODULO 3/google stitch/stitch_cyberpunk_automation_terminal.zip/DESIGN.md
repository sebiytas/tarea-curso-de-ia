---
name: Phosphor CLI / Cybernetic Terminal
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#b9ccb2'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#84967e'
  outline-variant: '#3b4b37'
  surface-tint: '#00e639'
  primary: '#ebffe2'
  on-primary: '#003907'
  primary-container: '#00ff41'
  on-primary-container: '#007117'
  inverse-primary: '#006e16'
  secondary: '#69df5c'
  on-secondary: '#003a03'
  secondary-container: '#2ca62a'
  on-secondary-container: '#003202'
  tertiary: '#edffe2'
  on-tertiary: '#003a00'
  tertiary-container: '#afed9d'
  on-tertiary-container: '#366d2c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#72ff70'
  primary-fixed-dim: '#00e639'
  on-primary-fixed: '#002203'
  on-primary-fixed-variant: '#00530e'
  secondary-fixed: '#85fd75'
  secondary-fixed-dim: '#69df5c'
  on-secondary-fixed: '#002201'
  on-secondary-fixed-variant: '#005306'
  tertiary-fixed: '#b5f3a2'
  tertiary-fixed-dim: '#99d688'
  on-tertiary-fixed: '#002200'
  on-tertiary-fixed-variant: '#1b5114'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-xl:
    fontFamily: Space Mono
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: 0em
  headline-md:
    fontFamily: Space Mono
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Space Mono
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-md:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: Space Mono
    fontSize: 9px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.12em
spacing:
  gutter: 1rem
  gutter-mobile: 0.5rem
  margin: 1.5rem
  margin-mobile: 0.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system channels an uncompromising retro-futuristic hacker console, drawing directly from 1980s mainframe monochrome CRTs, VT100 physical hardware, and high-stakes cyberpunk operational control desks. 

The aesthetic is grounded in utilitarian terminal computing and system automation. It avoids consumer-grade decoration, fluid gradients, organic curves, and skeuomorphic plastic. Instead, it commits entirely to razor-sharp wireframe geometries, high visual data density, phosphor electron-beam luminescence, and authentic Command Line Interface (CLI) interaction paradigms.

Targeted at infrastructure engineers, red-team operatives, and systems automation developers, this system evokes uncompromising technical command, raw compute execution, and focused clarity. Interfaces must look operational, uncompromising, and alive with system telemetries, ASCII architectural diagrams, and continuous telemetry feeds.

## Colors

The palette is strictly calibrated to emulate P1 green phosphor cathode-ray decay, operating against deep void backdrops.

- **Primary (`#00FF41`)**: High-excitation phosphor neon green. Used for critical system outputs, selected states, active cursor carats, primary telemetry readouts, and bright wireframe borders.
- **Secondary (`#008F11`)**: Decayed phosphor green. Used for secondary labels, inactive controls, breadcrumbs, timestamp meta-readouts, and low-priority operational data.
- **Tertiary (`#003B00`)**: Deep phosphor trace green. Used for structural grid divisions, inner terminal borders, nested hierarchy trees, and background fills of running execution states.
- **Neutral Surface (`#0A0A0A`)**: Elevated console card fill. Sits directly above the pure obsidian root background (`#000000`), establishing structural visual division without breaking terminal purity.
- **Alert / Overdrive Accent (`#FF0055`)**: Hard-coded crimson reserved exclusively for catastrophic process failure, kernel panic readouts, and unrecoverable pipeline terminations.

Color contrast is absolute. Elements rely on binary luminous transitions rather than alpha-blended transparency.

## Typography

Typography is 100% monospaced across all viewports and interface roles to enforce tabular column alignment and typewriter grid integrity.

All text elements are rendered in uppercase by default for headlines, status readouts, controls, and schema keys; lowercase is reserved for dynamic payload strings, code executions, and variable parameters. 

Primary interactive texts, titles, and active statuses feature an optical phosphor glow via text shadowing:
```css
text-shadow: 0 0 8px rgba(0, 255, 65, 0.6);
```
Muted and low-priority labels suppress this shadow entirely to maintain visual order and prevent halation blur across dense logs.

## Layout & Spacing

The layout philosophy follows a dense, full-bleed modular telemetry console. It is built upon a strict 8px base rhythm where elements snap to character-cell bounding boxes.

- **Desktop (>= 1024px)**: 12-column fluid grid system bounded by outer margins of `1.5rem` and gutters of `1rem`. Interfaces prioritize split-pane CLI layouts, multi-column pipeline trees, and fixed-height terminal panels.
- **Tablet (768px - 1023px)**: 8-column layout. Multi-column workspace panels collapse into stacked, border-linked terminal panes.
- **Mobile (< 768px)**: 4-column layout with compressed `0.75rem` margins and `0.5rem` gutters. Sideways tabular data converts to fixed horizontal-scroll streams.

Zero margin collapse is permitted. All layout modules are separated exclusively by explicit spacing tokens or connected directly along shared 1px borders.

## Elevation & Depth

This design system explicitly rejects modern surface elevations, drop shadows, and blur-based glassmorphism. Visual hierarchy is achieved exclusively through structural wireframe borders, tonal surface stepping, and phosphor radiance.

- **Baseline Canvas**: Solid pure black (`#000000`). Root layout background.
- **Surface Containment**: Raised containers utilize `#0A0A0A` with a mandatory `1px solid #008F11` or `1px solid #00FF41` wireframe perimeter.
- **Scanline Layer**: Overlaid across all terminal viewports using a non-blocking CSS overlay:
  ```css
  background: repeating-linear-gradient(
    0deg,
    rgba(0, 0, 0, 0.25),
    rgba(0, 0, 0, 0.25) 1px,
    transparent 1px,
    transparent 2px
  );
  pointer-events: none;
  ```
- **Depth via Luminance**: Active or focused windows gain high-excitation border glow:
  ```css
  box-shadow: 0 0 10px rgba(0, 255, 65, 0.35), inset 0 0 10px rgba(0, 255, 65, 0.1);
  ```
- **Z-Index Layering**: Modals and command palettes appear as framed ASCII floating buffers with an opaque `#000000` fill and high-contrast double borders (`border: 2px solid #00FF41`).

## Shapes

The roundedness across every component in the system is locked to `0` (`0px` / `rounded-none`). 

No curves, pills, or circular geometries are permitted. Interactive buttons, cards, dropdowns, input fields, badges, and progress meters are strictly orthogonal boxes. Visual cues that would typically use circles (such as radio toggles, avatar placeholders, and state indicators) are replaced by bracketed characters, square icons, or ASCII glyphs (`[ ]`, `[*]`, `[X]`, `[+]`, `[-]`).

## Components

### Buttons
All buttons mimic bracketed terminal commands. 
- **Default State**: Background transparent, border `1px solid #00FF41`, text `#00FF41`. Rendered as `[ ACTION_NAME ]`.
- **Hover State**: Direct inversion. Background `#00FF41`, border `1px solid #00FF41`, text `#000000` with zero text-shadow.
- **Active / Pressed**: Background `#008F11`, border `1px solid #008F11`, text `#000000`.
- **Secondary / Ghost**: Border `1px solid #008F11`, text `#008F11`. Inverts to `#008F11` fill on hover.

### Input Fields
Inputs replicate physical interactive CLI lines.
- Prefixed with an immutable prompt glyph: `> ` in `#00FF41`.
- Container is transparent or `#0A0A0A` with a bottom-only or fully enclosed `1px solid #008F11` outline.
- Active focus transitions the border to `#00FF41` with a pulsing block cursor (`█`) terminating the input string.

### Chips & Badges
Rectangular monospace indicators formatted as bracketed tags:
- `[STATUS: RUNNING]`: Border `1px solid #00FF41`, text `#00FF41`, background `rgba(0, 255, 65, 0.05)`.
- `[STATUS: IDLE]`: Border `1px solid #008F11`, text `#008F11`, background transparent.
- `[STATUS: FAILED]`: Border `1px solid #FF0055`, text `#FF0055`, background `rgba(255, 0, 85, 0.08)`.

### Checkboxes & Radios
Form selection elements avoid native OS styles in favor of terminal text markers:
- Unchecked: `[ ]` (`1px solid #008F11` square container).
- Checked: `[X]` or `[■]` filled with `#00FF41`.
- Radio Active: `(*)` using sharp bracketed ASCII styling.

### Cards & Panels
Panels mimic VT terminal frames:
- Outer border `1px solid #008F11`.
- Header bar features a solid `#0A0A0A` or inverted `#003B00` strip with a title syntax: `// PANEL: EXECUTION_GRAPH_V1.02`.
- Content padding set strictly to `space-md` (`1rem`).

### Lists & Tree Views
Hierarchical workflows and repository listings utilize raw box-drawing characters:
- Parent: `├── src/`
- Children: `│   ├── automation.sh`
- End nodes: `└── config.env`
- Selected rows gain an inverted phosphor highlight strip (Background `#00FF41`, Foreground `#000000`).

### Node Diagrams & Workflow Pipelines
Automated visual pipelines must never use curved Bezier splines. Connections between automation nodes are drawn strictly using 90-degree orthogonal green paths (`stroke: #00FF41; stroke-width: 1px; stroke-dasharray: 4px;` for running flows).