---
name: Studio Viewfinder Editorial
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1a'
  on-surface-variant: '#5f3f3a'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#946e68'
  outline-variant: '#e9bcb5'
  surface-tint: '#c00000'
  primary: '#b70100'
  on-primary: '#ffffff'
  primary-container: '#e60000'
  on-primary-container: '#fff7f5'
  inverse-primary: '#ffb4a8'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#00682c'
  on-tertiary: '#ffffff'
  tertiary-container: '#00843a'
  on-tertiary-container: '#e7ffe5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#930100'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#faf9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e3e2e0'
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 5rem
    fontWeight: '300'
    lineHeight: 5.25rem
    letterSpacing: -0.04em
  display-xl-mobile:
    fontFamily: Inter
    fontSize: 2.75rem
    fontWeight: '300'
    lineHeight: 3rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Inter
    fontSize: 3rem
    fontWeight: '400'
    lineHeight: 3.5rem
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '400'
    lineHeight: 2.375rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '500'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  label-hud-lg:
    fontFamily: Space Mono
    fontSize: 0.875rem
    fontWeight: '700'
    lineHeight: 1.25rem
    letterSpacing: 0.08em
  label-hud-md:
    fontFamily: Space Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0.05em
  label-hud-sm:
    fontFamily: Space Mono
    fontSize: 0.625rem
    fontWeight: '400'
    lineHeight: 0.875rem
    letterSpacing: 0.06em
  caption:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0.01em
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

This design system pairs the hyper-functional, precise instrumentation of a digital cinema viewfinder Heads-Up Display (HUD) with the refined, tactile calm of a high-key photo studio art book. It is engineered specifically for elite audiovisual directors, cinematographers, and high-fashion advertising agencies.

The emotional core is clinical artistic mastery: the feeling of looking through an Arri or RED camera monitor on a bright white cyclorama set. The visual narrative combines raw technical data—timecodes, focal lengths, audio meters, crop marks, and recording states—with generous, high-fashion editorial spacing. 

Key attributes:
- **Cinematic Precision**: Grid markers, framing brackets, exposure indexes, and razor-thin technical borders evoke specialized hardware.
- **Editorial High-Key**: Light, warm background washes emulate archival paper and bright studio light, avoiding the clichéd dark-mode production house aesthetic.
- **Tactile Urgency**: The iconic high-saturation 'REC' red punctures the neutral field to indicate active states, reel playback, and key user actions.

## Colors

The palette reproduces the environment of a physical camera shooting against a seamless white cyc wall under diffused 5600K lighting.

- **Primary (`#E60000`)**: Studio 'REC' Red. Reserved strictly for active capture states, record indicators, playhead focus, and primary conversion triggers. It must never be diluted with gradients.
- **Secondary (`#1A1A1A`)**: Optical Charcoal. Used for razor-sharp hairline borders, HUD framing brackets, crosshairs, and dominant editorial typography. It provides extreme, clinical contrast against the warm field.
- **Tertiary (`#22C55E`)**: Calibration Green. Used for broadcast audio level monitoring, battery nominal indicators, and metadata validation flags. (Paired alongside `#EAB308` Calibration Amber for meter headroom).
- **Neutral (`#FAF9F6`)**: Archival Cyc. A soft, warm off-white surface that mitigates optical fatigue, gives rich depth to embedded film frames, and sets a tactile foundation.
- **HUD Reticle Neutral (`#D1CEBD`)**: Used at 15% to 40% opacity for passive rule-of-thirds overlays, crop guide marks, and grid tick tracks.

## Typography

The typographic hierarchy establishes a dichotomy between Swiss-influenced humanistic typography and raw camera monitor telemetry:

- **Editorial Headings & Titles (`Inter`)**: Set light to medium with negative tracking to emulate high-end print monographs and commercial film slates. It yields maximum legibility without calling undue attention to itself, keeping the visual focus on cinematography.
- **HUD Metadata & Technical Telemetry (`Space Mono`)**: Used for all operational data—frame rates (e.g., `24.00 FPS`), aperture/ISO ratings (`T1.5`, `ISO 800`), timecodes (`01:23:45:12`), sensor dimensions, aspect ratios, and navigation labels. All numeric technical reads must utilize tabular figures to prevent jitter during real-time timeline scrubs or playback.
- **Case Rule**: All HUD labels, badges, and technical parameters must render strictly in `uppercase`.

## Layout & Spacing

The layout is grounded in a 12-column architectural grid framed within a universal viewport HUD boundary:

- **HUD Outer Frame**: The root application container enforces safe-action and safe-title boundaries. Corner tick marks and bleed guides anchor the primary layout margins (`2.5rem` desktop, `1rem` mobile).
- **Rule of Thirds Overlay**: Optional or layout-defining gridlines intersect key display modules at 33.3% and 66.6% intervals using 1px `#1A1A1A` at 10% opacity.
- **Responsive Adaptations**:
  - **Desktop (1024px+)**: 12-column layout. High-key negative space allows media cards to sit with intentional asymmetry, echoing magazine spreads. HUD telemetry hugs the viewport perimeter.
  - **Tablet (768px - 1023px)**: 8-column layout. Camera parameters dock to horizontal top/bottom bars. Gutters compress to `1rem`.
  - **Mobile (<768px)**: 4-column layout. Secondary HUD telemetry tucks into a consolidated collapsible top HUD ribbon (`FPS / ISO / TC`). Safe margins compress to `1rem`.

## Elevation & Depth

This system intentionally rejects diffuse ambient drop shadows, blurs, and skeuomorphic gradients. Depth is created strictly through technical registration layers and structural framing:

- **Layer 0 (Base Canvas)**: Archival warm cyc (`#FAF9F6`) acts as the base studio plate.
- **Layer 1 (Reticle & Registration)**: Hairline technical marks (1px solid `#1A1A1A` at 12–20% opacity) form registration crosses, aspect ratio cut lines (2.39:1, 16:9, 4:3), and perimeter brackets.
- **Layer 2 (Media Planes)**: High-resolution photographic stills and motion reels. Framed with sharp 1px outer borders or isolated inside open viewfinder crop marks.
- **Layer 3 (Active HUD Overlays & Floating Metadata)**: Telemetry badges, timecode counters, and audio meters float directly over media plates without background blurs, relying instead on high-contrast matte surfaces (`#FAF9F6` or `#1A1A1A`) and hairline strokes.
- **Layer 4 (Modals & Full-Screen Slates)**: Direct opaque cutovers. Full canvas shifts to Optical Charcoal (`#1A1A1A`) with stark `#FAF9F6` type for director treatment presentations and full-res screeners.

## Shapes

The design system enforces an uncompromising **0px border radius (Sharp)** across every UI element:

- All buttons, dialogs, inputs, thumbnail viewports, and status badges are hard-cornered rectangles.
- The sharpness pays direct homage to optical glass, sensor chips, slate clappers, and industrial cinema monitors.
- Structural accents use 45-degree corner notches or clipped corners (2px to 4px) exclusively on camera corner brackets, sensor status badges, and audio level meters.

## Components

### Buttons & Triggers
- **Primary Trigger (REC State)**: Solid `#1A1A1A` fill, `#FAF9F6` monospace text, featuring a 6px blinking or solid `#E60000` circle to the left. 0px corner radius. On hover: invert fill to `#E60000` with white text.
- **Secondary Wireframe**: 1px `#1A1A1A` border, transparent background, uppercase `Space Mono` label. On hover: background fills with `#1A1A1A`, text shifts to `#FAF9F6`.
- **Viewfinder Corner Triggers**: Borderless labels with micro corner brackets that expand outward by 2px on hover.

### HUD Viewfinder Brackets & Framing Cards
- **Portfolio Cards**: Media thumbnails sit within 4 corner brackets (L-shaped, 8px length, 1px solid `#1A1A1A`). The project aspect ratio (e.g., `[ 2.39 : 1 ]`) is pinned to the top-right bracket in `label-hud-sm`.
- **Hover State**: Corner brackets turn `#E60000`, and technical specs (Director, DP, Lens, Film Stock/Sensor) fade in via monospaced metadata badges.

### Audio Level Meter Indicators (VU Gauges)
- Segmented vertical or horizontal bar racks composed of 1px or 2px blocks separated by 1px gaps.
- Scale: `-∞` to `-12dB` in `#22C55E` (Tertiary), `-12dB` to `-3dB` in `#EAB308`, and `-3dB` to `0dB / PEAK` in `#E60000` (Primary). Placed adjacent to video showreels.

### Telemetry Badges & Chips
- Wireframe rectangles with 1px `#1A1A1A` borders containing metadata reads: `[ 24 FPS ]`, `[ 8K RAW ]`, `[ T1.3 ]`, `[ 800 ISO ]`.
- Background remains transparent; type is uppercase `Space Mono`.

### Film Timeline Ribbon
- Scrubbable interactive scrubber bar styled as an exposed 35mm film edge or NLE playhead.
- Features second/frame tick marks every 10px, current frame counter in `label-hud-md`, and a vertical 1px `#E60000` playhead needle.

### Input Fields & Slates
- Minimalist underline or 1px bounding box in `#1A1A1A`. 
- Input labels styled as slate markers: `SCENE // TAKE // INQUIRY`. Placeholder text rendered in muted monospace (`rgba(26, 26, 26, 0.4)`).
- Active focus displays an authoritative 1px solid `#E60000` ring or bottom border.